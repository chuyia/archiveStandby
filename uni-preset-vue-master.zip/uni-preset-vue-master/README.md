# @uni-app/vue-cli-preset-uni-app

> uni-app preset for vue-cli